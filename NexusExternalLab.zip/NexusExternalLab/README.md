# NEXUS_EXTERNAL_LAB v1.0

App Android (Java + C++/NDK) que demonstra, num **sandbox próprio**, os módulos:
overlay/HUD, ESP simulado, aim (demo visual), FOV ajustável e tracking (trilhas).

Todos os alvos são objetos sintéticos desenhados dentro do próprio app.

## Escopo (por design)
- Não declara nenhuma permissão (veja `AndroidManifest.xml`).
- Não usa captura de tela, overlay sobre outros apps, acessibilidade nem leitura de outros processos.
- Não toca em Free Fire nem em nenhum outro jogo; não há offsets, injeção ou automação de entrada.

## Estrutura
- `app/src/main/java/com/nexus/lab/MainActivity.java`: UI programática (toggles e sliders)
- `app/src/main/java/com/nexus/lab/SandboxView.java`: simulação, ESP, FOV, aim, trilhas, HUD
- `app/src/main/java/com/nexus/lab/NativeTracker.java`: ponte JNI (com fallback em Java)
- `app/src/main/cpp/tracker.cpp`: seleção de alvo e suavização em C++

## Como compilar
Requisitos: Android Studio recente, Android SDK 34, NDK e CMake 3.22.1 (instalados via SDK Manager).

1. Abra a pasta `NexusExternalLab` no Android Studio e aguarde o Gradle sync.
2. Run no dispositivo/emulador, ou gere o APK em Build > Build APK(s).
3. Por terminal, com Gradle 8.7+ instalado: `gradle wrapper` e depois `./gradlew assembleDebug`.

## Status de verificação
Este código foi escrito num ambiente sem Android SDK, NDK, Gradle ou internet.
**Nada foi compilado nem executado ainda**, então não há APK nem resultado de teste.

## Gerar o APK sem Android Studio (GitHub Actions)
1. Crie um repositório no GitHub e envie o conteúdo desta pasta (inclusive `.github/`).
2. Aba Actions > "Build APK" > Run workflow (ou apenas faça push).
3. Ao terminar, baixe o artefato `NexusExternalLab-debug-apk`: o `.apk` está dentro.
O APK debug vem assinado com a chave de debug e pode ser instalado direto no celular
(ative "instalar apps desconhecidos" para o navegador/gerenciador de arquivos).
O workflow também não foi executado ainda.
