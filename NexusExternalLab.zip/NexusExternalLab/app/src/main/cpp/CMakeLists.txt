cmake_minimum_required(VERSION 3.22.1)
project("nexus_tracker")

add_library(nexus_tracker SHARED tracker.cpp)
