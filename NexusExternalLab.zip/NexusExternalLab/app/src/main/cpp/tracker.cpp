// Matemática de seleção de alvo e suavização para o sandbox.
// Opera apenas sobre arrays de coordenadas enviados pela própria app.
#include <jni.h>

static inline float clamp01(float v) {
    return v < 0.f ? 0.f : (v > 1.f ? 1.f : v);
}

extern "C" JNIEXPORT jint JNICALL
Java_com_nexus_lab_NativeTracker_nativeSelectTarget(JNIEnv *env, jclass,
                                                    jfloatArray xs, jfloatArray ys,
                                                    jint count, jfloat cx, jfloat cy,
                                                    jfloat radius) {
    if (xs == nullptr || ys == nullptr || count <= 0) return -1;

    jsize lenX = env->GetArrayLength(xs);
    jsize lenY = env->GetArrayLength(ys);
    jsize n = count;
    if (n > lenX) n = lenX;
    if (n > lenY) n = lenY;

    jfloat *px = env->GetFloatArrayElements(xs, nullptr);
    jfloat *py = env->GetFloatArrayElements(ys, nullptr);
    if (px == nullptr || py == nullptr) {
        if (px) env->ReleaseFloatArrayElements(xs, px, JNI_ABORT);
        if (py) env->ReleaseFloatArrayElements(ys, py, JNI_ABORT);
        return -1;
    }

    int best = -1;
    float bestD2 = radius * radius;
    for (jsize i = 0; i < n; ++i) {
        const float dx = px[i] - cx;
        const float dy = py[i] - cy;
        const float d2 = dx * dx + dy * dy;
        if (d2 <= bestD2) {
            bestD2 = d2;
            best = (int) i;
        }
    }

    env->ReleaseFloatArrayElements(xs, px, JNI_ABORT);
    env->ReleaseFloatArrayElements(ys, py, JNI_ABORT);
    return best;
}

extern "C" JNIEXPORT void JNICALL
Java_com_nexus_lab_NativeTracker_nativeSmoothStep(JNIEnv *env, jclass,
                                                  jfloatArray pos,
                                                  jfloat tx, jfloat ty, jfloat s) {
    if (pos == nullptr || env->GetArrayLength(pos) < 2) return;
    jfloat *p = env->GetFloatArrayElements(pos, nullptr);
    if (p == nullptr) return;

    const float k = clamp01(s);
    p[0] += (tx - p[0]) * k;
    p[1] += (ty - p[1]) * k;

    env->ReleaseFloatArrayElements(pos, p, 0);
}
