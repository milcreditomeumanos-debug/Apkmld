package com.nexus.lab;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

import java.util.function.IntConsumer;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        final int pad = dp(10);
        final SandboxView sandbox = new SandboxView(this);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF0B0F14);
        root.addView(sandbox, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(pad, pad, pad, pad);

        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        row1.addView(check("HUD", true, sandbox::setHud), weight());
        row1.addView(check("ESP", true, sandbox::setEsp), weight());
        row1.addView(check("AIM", true, sandbox::setAim), weight());
        panel.addView(row1);

        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        row2.addView(check("FOV", true, sandbox::setFov), weight());
        row2.addView(check("Trilhas", true, sandbox::setTrails), weight());
        panel.addView(row2);

        addSlider(panel, "Raio do FOV (dp)", 300, 90,
                p -> sandbox.setFovRadiusDp(60 + p), p -> String.valueOf(60 + p));
        addSlider(panel, "Suavização do aim", 49, 11,
                p -> sandbox.setSmoothing((p + 1) / 100f),
                p -> String.format(java.util.Locale.US, "%.2f", (p + 1) / 100f));
        addSlider(panel, "Alvos de teste", 11, 5,
                p -> sandbox.setTargetCount(p + 1), p -> String.valueOf(p + 1));

        ScrollView scroll = new ScrollView(this);
        scroll.addView(panel);
        root.addView(scroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 0.6f));

        setContentView(root);
    }

    private interface Formatter {
        String format(int progress);
    }

    private interface BoolConsumer {
        void accept(boolean value);
    }

    private CheckBox check(String label, boolean initial, final BoolConsumer onChange) {
        CheckBox cb = new CheckBox(this);
        cb.setText(label);
        cb.setTextColor(Color.WHITE);
        cb.setChecked(initial);
        cb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton b, boolean checked) {
                onChange.accept(checked);
            }
        });
        onChange.accept(initial);
        return cb;
    }

    private void addSlider(LinearLayout parent, final String label, int max, int initial,
                           final IntConsumer onChange, final Formatter fmt) {
        final TextView title = new TextView(this);
        title.setTextColor(Color.WHITE);
        title.setText(label + ": " + fmt.format(initial));
        parent.addView(title);

        SeekBar bar = new SeekBar(this);
        bar.setMax(max);
        bar.setProgress(initial);
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar s, int progress, boolean fromUser) {
                onChange.accept(progress);
                title.setText(label + ": " + fmt.format(progress));
            }

            @Override public void onStartTrackingTouch(SeekBar s) {}
            @Override public void onStopTrackingTouch(SeekBar s) {}
        });
        parent.addView(bar);
        onChange.accept(initial);
    }

    private LinearLayout.LayoutParams weight() {
        return new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
