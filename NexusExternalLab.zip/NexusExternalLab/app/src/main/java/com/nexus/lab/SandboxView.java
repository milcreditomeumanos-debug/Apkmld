package com.nexus.lab;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Random;

/**
 * Sandbox 100% interno: todos os alvos são objetos sintéticos desenhados
 * nesta própria View. Nada é lido de outro app, tela ou processo.
 *
 * Módulos: overlay/HUD, ESP simulado, aim (demo visual), FOV, tracking (trilhas).
 */
public class SandboxView extends View {

    private static final int MAX_TARGETS = 12;
    private static final int TRAIL_LEN = 24;

    private static final class Target {
        final int id;
        float x, y, vx, vy, r;
        final float[] trailX = new float[TRAIL_LEN];
        final float[] trailY = new float[TRAIL_LEN];
        int trailHead = 0, trailCount = 0;
        // "Detecção" simulada: caixa com ruído e confiança
        boolean detected, boxInit;
        float boxCx, boxCy, boxHalf, conf, dist;

        Target(int id) {
            this.id = id;
        }
    }

    private final List<Target> targets = new ArrayList<>();
    private final Random rng = new Random(42);
    private final float density;
    private int nextId = 1;

    private final float[] xs = new float[MAX_TARGETS];
    private final float[] ys = new float[MAX_TARGETS];
    private final float[] reticle = new float[2];
    private boolean reticleInit = false;
    private int lockedIndex = -1;

    private long lastNanos = 0;
    private float fps = 0f;

    // Configuração (alterada pela UI)
    private boolean hudOn = true, espOn = true, aimOn = true, fovOn = true, trailsOn = true;
    private float fovRadiusPx;
    private float smoothing = 0.12f;
    private int targetCount = 6;

    private final Paint bgPaint = new Paint();
    private final Paint gridPaint = new Paint();
    private final Paint targetPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint boxPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fovPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint reticlePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint trailPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();

    public SandboxView(Context context) {
        super(context);
        density = context.getResources().getDisplayMetrics().density;
        fovRadiusPx = 150f * density;

        bgPaint.setColor(0xFF0F1720);
        gridPaint.setColor(0x22FFFFFF);
        gridPaint.setStrokeWidth(1f);

        targetPaint.setColor(0xFFFFA726);

        boxPaint.setStyle(Paint.Style.STROKE);
        boxPaint.setStrokeWidth(2f * density);

        textPaint.setColor(Color.WHITE);
        textPaint.setTextSize(11f * density);

        fovPaint.setStyle(Paint.Style.STROKE);
        fovPaint.setStrokeWidth(1.5f * density);
        fovPaint.setColor(0xAA4FC3F7);

        reticlePaint.setStyle(Paint.Style.STROKE);
        reticlePaint.setStrokeWidth(2f * density);

        trailPaint.setStyle(Paint.Style.STROKE);
        trailPaint.setStrokeWidth(2f * density);
        trailPaint.setColor(0xFF4FC3F7);
    }

    // ----- Configuração -----

    public void setHud(boolean on) { hudOn = on; }
    public void setEsp(boolean on) { espOn = on; }
    public void setAim(boolean on) { aimOn = on; }
    public void setFov(boolean on) { fovOn = on; }
    public void setTrails(boolean on) { trailsOn = on; }
    public void setFovRadiusDp(float dp) { fovRadiusPx = dp * density; }
    public void setSmoothing(float s) { smoothing = Math.max(0.01f, Math.min(0.9f, s)); }
    public void setTargetCount(int n) { targetCount = Math.max(1, Math.min(MAX_TARGETS, n)); }

    // ----- Simulação -----

    private Target spawn(int w, int h) {
        Target t = new Target(nextId++);
        t.r = (14f + rng.nextFloat() * 10f) * density;
        t.x = t.r + rng.nextFloat() * Math.max(1f, w - 2f * t.r);
        t.y = t.r + rng.nextFloat() * Math.max(1f, h - 2f * t.r);
        float speed = (60f + rng.nextFloat() * 140f) * density;
        double ang = rng.nextDouble() * Math.PI * 2.0;
        t.vx = (float) Math.cos(ang) * speed;
        t.vy = (float) Math.sin(ang) * speed;
        return t;
    }

    private void step(float dt) {
        final int w = getWidth();
        final int h = getHeight();
        if (w == 0 || h == 0) return;

        if (!reticleInit) {
            reticle[0] = w / 2f;
            reticle[1] = h / 2f;
            reticleInit = true;
        }

        while (targets.size() < targetCount) targets.add(spawn(w, h));
        while (targets.size() > targetCount) targets.remove(targets.size() - 1);

        final float maxDist = (float) Math.hypot(w, h);
        final int n = targets.size();

        for (int i = 0; i < n; i++) {
            Target t = targets.get(i);

            t.x += t.vx * dt;
            t.y += t.vy * dt;
            if (t.x < t.r) { t.x = t.r; t.vx = Math.abs(t.vx); }
            else if (t.x > w - t.r) { t.x = w - t.r; t.vx = -Math.abs(t.vx); }
            if (t.y < t.r) { t.y = t.r; t.vy = Math.abs(t.vy); }
            else if (t.y > h - t.r) { t.y = h - t.r; t.vy = -Math.abs(t.vy); }

            // Tracking: trilha em buffer circular
            t.trailX[t.trailHead] = t.x;
            t.trailY[t.trailHead] = t.y;
            t.trailHead = (t.trailHead + 1) % TRAIL_LEN;
            if (t.trailCount < TRAIL_LEN) t.trailCount++;

            xs[i] = t.x;
            ys[i] = t.y;

            // ESP simulado: "detecção" com ruído, só dentro do FOV (se ativo)
            t.dist = (float) Math.hypot(t.x - reticle[0], t.y - reticle[1]);
            t.detected = !fovOn || t.dist <= fovRadiusPx;
            if (t.detected) {
                float cx = t.x + (rng.nextFloat() - 0.5f) * 4f * density;
                float cy = t.y + (rng.nextFloat() - 0.5f) * 4f * density;
                if (!t.boxInit) {
                    t.boxCx = cx;
                    t.boxCy = cy;
                    t.boxInit = true;
                } else {
                    t.boxCx += (cx - t.boxCx) * 0.5f;
                    t.boxCy += (cy - t.boxCy) * 0.5f;
                }
                t.boxHalf = t.r * 1.25f + (rng.nextFloat() - 0.5f) * 2f * density;
                float c = 0.97f - 0.35f * (t.dist / maxDist) + (rng.nextFloat() - 0.5f) * 0.04f;
                t.conf = Math.max(0.5f, Math.min(0.99f, c));
            } else {
                t.boxInit = false;
            }
        }

        // Aim (demo visual): a mira virtual do sandbox desliza até o alvo mais próximo
        lockedIndex = -1;
        if (aimOn) {
            float radius = fovOn ? fovRadiusPx : 1e9f;
            lockedIndex = NativeTracker.selectTarget(xs, ys, n, reticle[0], reticle[1], radius);
            if (lockedIndex >= 0) {
                float s = 1f - (float) Math.pow(1f - smoothing, dt * 60f);
                NativeTracker.smoothStep(reticle, xs[lockedIndex], ys[lockedIndex], s);
            }
        }
    }

    // ----- Desenho -----

    @Override
    protected void onDraw(Canvas c) {
        long now = System.nanoTime();
        float dt = lastNanos == 0 ? 1f / 60f : (now - lastNanos) / 1e9f;
        lastNanos = now;
        dt = Math.max(0.001f, Math.min(0.05f, dt));
        fps = fps == 0f ? 1f / dt : fps * 0.9f + (1f / dt) * 0.1f;

        step(dt);

        final int w = getWidth();
        final int h = getHeight();
        c.drawRect(0, 0, w, h, bgPaint);

        float grid = 64f * density;
        for (float gx = 0; gx < w; gx += grid) c.drawLine(gx, 0, gx, h, gridPaint);
        for (float gy = 0; gy < h; gy += grid) c.drawLine(0, gy, w, gy, gridPaint);

        final int n = targets.size();

        // Tracking: trilhas
        if (trailsOn) {
            for (int i = 0; i < n; i++) {
                Target t = targets.get(i);
                int oldest = (t.trailHead - t.trailCount + TRAIL_LEN) % TRAIL_LEN;
                for (int k = 0; k < t.trailCount - 1; k++) {
                    int a = (oldest + k) % TRAIL_LEN;
                    int b = (oldest + k + 1) % TRAIL_LEN;
                    trailPaint.setAlpha(30 + (int) (150f * k / TRAIL_LEN));
                    c.drawLine(t.trailX[a], t.trailY[a], t.trailX[b], t.trailY[b], trailPaint);
                }
            }
        }

        // Alvos de teste
        for (int i = 0; i < n; i++) {
            Target t = targets.get(i);
            c.drawCircle(t.x, t.y, t.r, targetPaint);
        }

        // FOV ao redor da mira
        if (fovOn && reticleInit) {
            c.drawCircle(reticle[0], reticle[1], fovRadiusPx, fovPaint);
        }

        // ESP simulado
        if (espOn) {
            for (int i = 0; i < n; i++) {
                Target t = targets.get(i);
                if (!t.detected || !t.boxInit) continue;
                boxPaint.setColor(i == lockedIndex ? 0xFFFF5252 : 0xFF69F0AE);
                rect.set(t.boxCx - t.boxHalf, t.boxCy - t.boxHalf,
                         t.boxCx + t.boxHalf, t.boxCy + t.boxHalf);
                c.drawRect(rect, boxPaint);
                String label = String.format(Locale.US, "T%d  %.2f  %dpx  SIM",
                        t.id, t.conf, Math.round(t.dist));
                c.drawText(label, rect.left, rect.top - 4f * density, textPaint);
            }
        }

        // Mira virtual do sandbox
        if (reticleInit) {
            reticlePaint.setColor(lockedIndex >= 0 ? 0xFFFF5252 : 0xFF69F0AE);
            float gap = 4f * density;
            float len = 12f * density;
            float rx = reticle[0];
            float ry = reticle[1];
            c.drawLine(rx - gap - len, ry, rx - gap, ry, reticlePaint);
            c.drawLine(rx + gap, ry, rx + gap + len, ry, reticlePaint);
            c.drawLine(rx, ry - gap - len, rx, ry - gap, reticlePaint);
            c.drawLine(rx, ry + gap, rx, ry + gap + len, reticlePaint);
            c.drawCircle(rx, ry, 6f * density, reticlePaint);
        }

        // HUD (overlay interno)
        if (hudOn) {
            float line = 14f * density;
            float x = 8f * density;
            float y = 18f * density;
            String lock = lockedIndex >= 0 ? "T" + targets.get(lockedIndex).id : "-";
            c.drawText(String.format(Locale.US, "FPS %.0f | alvos %d | lock %s", fps, n, lock),
                    x, y, textPaint);
            c.drawText("C++ nativo: " + (NativeTracker.isNativeAvailable() ? "sim" : "não (fallback Java)"),
                    x, y + line, textPaint);
            c.drawText("Sandbox: objetos simulados, nenhum jogo é lido ou alterado",
                    x, h - 8f * density, textPaint);
        }

        postInvalidateOnAnimation();
    }

    // ----- Toque: arrastar move a mira virtual -----

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
            case MotionEvent.ACTION_MOVE:
                reticle[0] = Math.max(0f, Math.min(getWidth(), e.getX()));
                reticle[1] = Math.max(0f, Math.min(getHeight(), e.getY()));
                reticleInit = true;
                return true;
            case MotionEvent.ACTION_UP:
                performClick();
                return true;
            default:
                return super.onTouchEvent(e);
        }
    }

    @Override
    public boolean performClick() {
        return super.performClick();
    }
}
