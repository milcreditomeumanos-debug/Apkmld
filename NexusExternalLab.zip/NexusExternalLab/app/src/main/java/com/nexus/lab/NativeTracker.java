package com.nexus.lab;

/**
 * Ponte JNI para tracker.cpp. Se a lib nativa não carregar,
 * usa implementações equivalentes em Java.
 */
public final class NativeTracker {

    private static final boolean NATIVE;

    static {
        boolean ok;
        try {
            System.loadLibrary("nexus_tracker");
            ok = true;
        } catch (UnsatisfiedLinkError e) {
            ok = false;
        }
        NATIVE = ok;
    }

    private NativeTracker() {}

    public static boolean isNativeAvailable() {
        return NATIVE;
    }

    /** Índice do alvo mais próximo de (cx, cy) dentro do raio, ou -1. */
    public static int selectTarget(float[] xs, float[] ys, int count,
                                   float cx, float cy, float radius) {
        if (NATIVE) {
            return nativeSelectTarget(xs, ys, count, cx, cy, radius);
        }
        int best = -1;
        float bestD2 = radius * radius;
        for (int i = 0; i < count; i++) {
            float dx = xs[i] - cx;
            float dy = ys[i] - cy;
            float d2 = dx * dx + dy * dy;
            if (d2 <= bestD2) {
                bestD2 = d2;
                best = i;
            }
        }
        return best;
    }

    /** Move pos[0..1] em direção a (tx, ty) pela fração s (0..1). */
    public static void smoothStep(float[] pos, float tx, float ty, float s) {
        if (NATIVE) {
            nativeSmoothStep(pos, tx, ty, s);
            return;
        }
        float k = Math.max(0f, Math.min(1f, s));
        pos[0] += (tx - pos[0]) * k;
        pos[1] += (ty - pos[1]) * k;
    }

    private static native int nativeSelectTarget(float[] xs, float[] ys, int count,
                                                 float cx, float cy, float radius);

    private static native void nativeSmoothStep(float[] pos, float tx, float ty, float s);
}
